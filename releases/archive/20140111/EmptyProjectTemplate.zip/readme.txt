Usage:
 ant Create
 
Console asks for project name that will be appendend to standard project classpath like

WrenchDb.Web.<<ProjectName>>

See  http://wrenchdb.codeplex.com/documentation for more info.